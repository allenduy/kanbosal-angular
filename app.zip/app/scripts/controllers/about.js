'use strict';

/**
 * @ngdoc function
 * @name kanbosalApp.controller:AboutController
 * @description
 * # AboutController
 * Controller of the kanbosalApp
 */
angular.module('kanbosalApp')
  .controller('AboutController', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });

'use strict';

/**
 * @ngdoc function
 * @name kanbosalApp.controller:MainController
 * @description
 * # MainController
 * Controller of the kanbosalApp
 */
angular.module('kanbosalApp')
  .controller('MainController', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });

angular.module('kanbosalApp')
.service('grantService', ['', function () {
  
}]);